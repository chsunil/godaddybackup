
		
        
        <!--to top button-->
        <a class="to-top" href="#"><i class="fa fa-long-arrow-up"></i></a>
     	
	<?php wp_footer(); ?>
	</body>
</html>