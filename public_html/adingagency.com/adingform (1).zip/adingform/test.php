<?php
echo "Hello it works";
?>